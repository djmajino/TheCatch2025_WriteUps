# CLASSIFIED – PROJECT SEISMOVOLT

* **Document ID**: SV-PP-ALPHA-2025-07
* **Clearance Level**: EYES ONLY – GRID OPS / URBAN INFRA ENGINEERING
* **Date**: 2025-08-14

## PROJECT NAME:
Seismovolt – Urban Vibrational Energy Plant

## OBJECTIVE:
To harness ground vibrations caused by cars, trams, and other urban activities to generate electrical power, store it, and supply it to the local grid during peak demand periods.

## RATIONALE:
Studies show that urban areas experience micro-seismic activity up to 0.3 mm displacement whenever a tram passes or a heavy truck hits a pothole. These vibrations are currently wasted (and sometimes just make coffee spill in the break room). The Shaking Power Plant aims to convert these harmless tremors into usable electricity.

## PRINCIPLE OF OPERATION:

* Install **Piezoelectric Deep Pads** (PDP) beneath tram lines, bus stops, and high-traffic roads.
* As vehicles pass, mechanical stress in PDPs generates voltage.
* Voltage is rectified, regulated, and stored in **Urban Tremor Batteries** (UTBs).
* Output is fed into substation microinverters for grid synchronization.

## EXPECTED PERFORMANCE:

* Tram crossing every 3 minutes: ~4.8 kWh/day from a 50 m section.
* Rush hour in central district: potential peak of 80–120 kWh/day.
* Bonus output on days with roadworks, music festivals, or earthquakes.

## RISKS & CHALLENGES:

* **Overload during seismic events**: May accidentally power entire block’s air conditioners for 3 hours.
* **Noise coupling**: Some residents reported their fridge “singing” in tune with tram schedules.
* **Pigeon interference**: Birds like warm PDP covers, reducing efficiency by 2–3%.

## FIELD TEST LOG – PROTOTYPE #1:

* **Location**: 4th Street Tram Crossing
* **Results**: Generated 312 Wh during morning rush hour; unplanned bonus when an ice cream truck hit a speed bump at 42 km/h.
* **Notes**: PDP cover plate loosened after series of aggressive skateboarding jumps — recommend stronger bolts or skatepark relocation.

## SECURITY NOTICE:
This technology is not to be shared with rollercoaster operators or heavy metal festival organizers without prior authorization from Grid Ops HQ.