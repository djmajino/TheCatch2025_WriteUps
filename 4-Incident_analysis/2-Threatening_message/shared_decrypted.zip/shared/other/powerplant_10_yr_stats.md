---
# Power Plant Statistics (2016-2025)

## Plant Status Table

| Code   | Name                     | Employees | State 2016 | State 2017 | State 2018 | State 2019 | State 2020 | State 2021 | State 2022 | State 2023 | State 2024 | State 2025 |
|--------|--------------------------|-----------|------------|------------|------------|------------|------------|------------|------------|------------|------------|------------|
| PP001  | Riverbend Hydro          | 82        | Good       | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP002  | Granite Peak Nuclear     | 310       | Good       | Good       | Needs minor repairs | Needs minor repairs | Good | Excellent | Excellent | Needs minor repairs | Good | Needs minor repairs |
| PP003  | Sunnyvale Solar Farm     | 15        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP004  | Windy Plains Windpark    | 22        | Good       | Good       | Excellent  | Excellent  | Good | Good | Excellent | Good | Good | Good |
| PP005  | Ironclad Coal Plant      | 120       | Needs maintenance | Needs maintenance | Good | Needs maintenance | Good | Good | Needs maintenance | Good | Good | Needs maintenance |
| PP006  | Bluewave Tidal           | 18        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP007  | Mountainview Nuclear     | 295       | Good       | Good       | Needs minor repairs | Needs minor repairs | Good | Excellent | Excellent | Needs minor repairs | Good | Needs minor repairs |
| PP008  | Greenfield Biomass       | 55        | Good       | Excellent  | Good | Excellent | Good | Excellent | Good | Good | Good | Good |
| PP009  | Starlight Solar          | 12        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP010  | Thunderbolt Hydro        | 80        | Good       | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP011  | Coalridge Thermal        | 125       | Needs maintenance | Needs maintenance | Good | Needs maintenance | Good | Good | Needs maintenance | Good | Good | Needs maintenance |
| PP012  | Northwind Windpark       | 20        | Good       | Good       | Excellent  | Excellent  | Good | Good | Excellent | Good | Good | Good |
| PP013  | Horizon Nuclear          | 305       | Good       | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP014  | Desert Sun Solar         | 14        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP015  | Rivermill Hydro          | 78        | Good       | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP016  | Blackrock Coal           | 128       | Needs maintenance | Needs maintenance | Good | Needs maintenance | Good | Good | Needs maintenance | Good | Good | Needs maintenance |
| PP017  | Oceanwave Tidal          | 17        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP018  | Forestview Biomass       | 60        | Good       | Good       | Excellent  | Excellent  | Good | Good | Excellent | Good | Good | Good |
| PP019  | Skylight Solar           | 13        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP020  | Rapidfall Hydro          | 82        | Good       | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |
| PP021  | Ember Coal Plant         | 130       | Needs maintenance | Needs maintenance | Good | Needs maintenance | Good | Good | Needs maintenance | Good | Good | Needs maintenance |
| PP022  | Windcrest Windpark       | 22        | Good       | Good       | Excellent  | Excellent  | Good | Good | Excellent | Good | Good | Good |
| PP023  | Aurora Nuclear           | 310       | Good       | Good       | Needs minor repairs | Needs minor repairs | Good | Excellent | Excellent | Needs minor repairs | Good | Needs minor repairs |
| PP024  | Sunridge Solar Farm      | 11        | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  | Excellent  |

## Yearly Output (GWh)

| Code   | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 |
|--------|------|------|------|------|------|------|------|------|------|
| PP001  | 1780 | 1810 | 1790 | 1820 | 1830 | 1850 | 1870 | 1890 | 1810 |
| PP002  | 9500 | 9600 | 9700 | 9750 | 9780 | 9800 | 9850 | 9870 | 9740 |
| PP003  | 400  | 410  | 415  | 420  | 425  | 430  | 430  | 420  | 415  |
| PP004  | 700  | 710  | 720  | 730  | 740  | 750  | 760  | 770  | 740  |
| PP005  | 4500 | 4520 | 4550 | 4570 | 4600 | 4620 | 4650 | 4670 | 4630 |
| PP006  | 380  | 390  | 395  | 400  | 405  | 410  | 415  | 420  | 410  |
| PP007  | 8900 | 8950 | 9000 | 9050 | 9100 | 9150 | 9200 | 9250 | 8900 |
| PP008  | 1000 | 1020 | 1010 | 1030 | 1040 | 1050 | 1060 | 1070 | 1050 |
| PP009  | 310  | 315  | 320  | 325  | 330  | 335  | 340  | 330  | 320  |
| PP010  | 2050 | 2060 | 2070 | 2080 | 2090 | 2100 | 2110 | 2120 | 2100 |
| PP011  | 4800 | 4820 | 4850 | 4870 | 4900 | 4920 | 4950 | 4970 | 4930 |
| PP012  | 740  | 750  | 760  | 770  | 780  | 790  | 800  | 810  | 780  |
| PP013  | 9300 | 9350 | 9400 | 9450 | 9500 | 9550 | 9600 | 9650 | 9400 |
| PP014  | 390  | 395  | 400  | 405  | 410  | 415  | 420  | 425  | 410  |
| PP015  | 1950 | 1970 | 1980 | 1990 | 2000 | 2010 | 2020 | 2030 | 2000 |
| PP016  | 4650 | 4670 | 4700 | 4720 | 4750 | 4770 | 4800 | 4820 | 4780 |
| PP017  | 420  | 425  | 430  | 435  | 440  | 445  | 450  | 455  | 440  |
| PP018  | 1050 | 1060 | 1070 | 1080 | 1090 | 1100 | 1110 | 1120 | 1080 |
| PP019  | 320  | 325  | 330  | 335  | 340  | 345  | 350  | 355  | 340  |
| PP020  | 2100 | 2110 | 2120 | 2130 | 2140 | 2150 | 2160 | 2170 | 2140 |
| PP021  | 4700 | 4720 | 4750 | 4770 | 4800 | 4820 | 4850 | 4870 | 4820 |
| PP022  | 770  | 780  | 790  | 800  | 810  | 820  | 830  | 840  | 810  |
| PP023  | 9600 | 9650 | 9700 | 9750 | 9800 | 9850 | 9900 | 9950 | 9700 |
| PP024  | 350  | 355  | 360  | 365  | 370  | 375  | 380  | 385  | 370  |

