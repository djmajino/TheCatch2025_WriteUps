# TCC PowerGrid: Power Station Repair Log

* Period: 
	* from: 01 Jan 2025
	* to: day 
* **2025-01-03 – Riverbend Hydro**
	* Issue: Unit 2 turbine tripped due to overspeed. Cause traced to a frozen sensor reporting “zero load” when, in fact, the turbine was working harder than a cat trying to bury poop on a marble floor.
	*  Mitigation: Sensor thawed with industrial heat gun, recalibrated, and bribed with preventive maintenance. Unit back online in 2 hours.
* **2025-02-14 – Coalridge Substation**
	* Issue: Transformer T3 oil leak detected. Leak location: bottom gasket — suspiciously close to where Dave from maintenance “just tightened things a little” last week.
	*  Mitigation: Gasket replaced, oil topped up, Dave banned from “tightening things” without a buddy system.
*  **2025-03-09 – Aurora Nuclear Plant**
	* Issue: Control panel buttons sticking due to excessive application of “operator snack grease” (translation: someone ate chicken wings during night shift).
	* Mitigation: Full panel cleaning, installation of a NO FOOD NEAR CONTROLS sign, which was promptly ignored.
* **2025-04-21 – Rapidfall Hydro**
	* Issue: Gate actuator stuck half-open, limiting water flow and power output. Cause: a fish somehow lodged itself exactly where it could jam the actuator arm.
	* Mitigation: Fish removed and released downstream (given a stern lecture about industrial safety). Gate lubricated and tested.
* **2025-05-28 – Eastline Station**
	* Issue: Alarm for “inverter overheating” turned out to be a rogue wasp nest inside the cooling duct, blocking airflow.
	* Mitigation: Wasps relocated to “somewhere not involving 600 volts,” duct cleaned, extra mesh installed. Wasps filed complaint (probably).
* **2025-06-16 – Granite Peak Substation**
	* Issue: Protective relay tripped due to software glitch — after a firmware update decided that any load above 20 MW was “too much excitement.”
	* Mitigation: Firmware rolled back, vendor sent a “strongly worded patch.” Relay now only trips when it’s actually supposed to.
* **2025-07-04 – Central City Station**
	* Issue: Generator G5 shut down unexpectedly. Root cause: a seagull carrying a half-eaten sandwich flew into the intake vent. Sandwich partially recovered; seagull unharmed but offended.
	* Mitigation: Intake mesh reinforced, sandwich disposed of (not eaten, despite speculation).
* **2025-08-12 – Southbridge Switching Yard**
	* Issue: Ground fault detected during storm. Turns out a maintenance ladder was accidentally left leaning on the busbar after lunch break.
	* Mitigation: Ladder removed, grounding checked, operator in charge given a bright orange DO NOT LEAVE NEAR LIVE EQUIPMENT flag to wave during safety briefings.
* **2025-08-14 – Horizon Nuclear Fusion Facility**
	* Issue: Experimental magnetic confinement test resulted in “unexpected localized gravitational anomaly.” Control room display briefly reported Black Hole Containment: ACTIVE. Operators unsure whether this was a sensor glitch or… you know… the other thing.
	* Mitigation: Emergency plasma dump triggered, magnetic field reset, anomaly readings returned to zero. Safety committee advised that, if a black hole was created, it was “very, very small” and “probably left already.” Lunch break resumed with only mild existential dread.

**Overall Summary:**

* Grid remained operational with <0.5% downtime. 
* Lessons learned: wasps love warm electronics, fish ignore safety signage, and engineers need more coffee than they admit.